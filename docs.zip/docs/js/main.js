$(function(){

$('.menu-btn').click(function(){
	$(this).toggleClass('active');
	$('.menu').toggleClass('active');
})


});